<?php
include 'dbconn.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    http_response_code(403);
    echo json_encode(['error' => 'You must be logged in to borrow a book.']);
    exit;
}

$username = $_SESSION['username'];

// Get input data
$data = json_decode(file_get_contents('php://input'), true);
$bookId = $data['id'] ?? null;

// Check if the bookId is valid
if ($bookId === null) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid book ID.']);
    exit;
}

$sql = "SELECT status, users_username FROM book_info WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $bookId);
$stmt->execute();
$stmt->bind_result($currentStatus, $borrowerUsername);
$stmt->fetch();
$stmt->close();

// Handle different book status
switch ($currentStatus) {
    case 'Available':
        // Mark as 'Pending' when a user borrows an available book
        $newStatus = 'Pending';

        $updateSql = "UPDATE book_info SET status = ?, users_username = ? WHERE id = ?";
        $updateStmt = $conn->prepare($updateSql); //execute
        $updateStmt->bind_param('ssi', $newStatus, $username, $bookId); //pinaltan status -> new status

        if ($updateStmt->execute()) {//update to pending
            echo json_encode(['success' => true, 'new_status' => $newStatus, 'action' => 'Pending']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to update the book status.']);
        }

        $updateStmt->close();
        break;

    case 'Pending':
        // checker if its pending on other users
        if ($borrowerUsername === $username) {
            echo json_encode(['success' => true, 'status' => 'Pending', 'action' => 'Pending']);
        } else {
            echo json_encode(['success' => true, 'status' => 'Unavailable', 'action' => 'Unavailable']);
        }
        break;

    case 'Borrowed':
        // checkr if its borrowed already by other users
        if ($borrowerUsername === $username) {
            echo json_encode(['success' => true, 'status' => 'Borrowed', 'action' => 'Borrowed']);
        } else {
            echo json_encode(['success' => true, 'status' => 'Unavailable', 'action' => 'Unavailable']);
        }
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid book status.']);
        exit;
}

$conn->close();
?>
