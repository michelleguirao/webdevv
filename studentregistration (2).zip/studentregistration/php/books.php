<?php
include 'dbconn.php';

header('Content-Type: application/json');

// Query to fetch all books with their details
$query = "SELECT id, bname, author, date, synopsis, img_directory, status, users_username FROM book_info";
$result = $conn->query($query);

$books = [];
while ($row = $result->fetch_assoc()) {
    $books[] = [
        'id' => $row['id'],
        'bname' => $row['bname'],
        'author' => $row['author'],
        'date' => $row['date'],
        'synopsis' => $row['synopsis'],
        'img_directory' => 'public/img/bookpicture/' . $row['img_directory'], // Adjusted image path
        'status' => $row['status'],
        'users_username' => $row['users_username'],
    ];
}

// Check if books were found
if (count($books) > 0) {
    echo json_encode($books);
} else {
    echo json_encode(['error' => 'No books found.']);
}

$conn->close();
?>
