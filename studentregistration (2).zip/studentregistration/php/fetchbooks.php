<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('dbconn.php'); // Include database connection

$config = new Config();
$conn = $config->conn;

if (isset($_POST['fetch'])) {
    $sql = "SELECT * FROM book_info";
    $result = $conn->query($sql);

    $books = [];
    while ($row = $result->fetch_assoc()) {
        // Convert LONG BLOB (binary data) to base64
        if (!empty($row['img_directory'])) {
            //  $imageType = mime_content_type($row['img_directory']);
            $row['img_directory'] = base64_encode($row['img_directory']);
            // $row['img_mime'] = $imageType;
            
        }
        $books[] = $row;
    }
    echo json_encode($books);
    exit;
}

$conn->close();
?>
