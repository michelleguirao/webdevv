<?php
include("dbconn.php");
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    echo json_encode(["error" => "You are not logged in."]);
    exit();
}

// Get the username from the session
$username = $_SESSION['username'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['profile_picture'])) {
        $file = $_FILES['profile_picture'];

        // Validate file upload
        if ($file['error'] === UPLOAD_ERR_OK) {
            $uploadsDir = '../public/img/userprofilepicture/'; // Directory to store the images
            $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            // Validate the file type (allow only certain image types)
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($extension, $allowedExtensions)) {
                echo json_encode(["error" => "Invalid file type."]);
                exit();
            }

            // Ensure uploads directory exists
            if (!is_dir($uploadsDir)) {
                mkdir($uploadsDir, 0777, true); // Create the folder if it doesn't exist
            }

            // Generate the filename and update the profile_picture attribute in the database
            $newFilename = $username . '.' . $extension;
            $targetFile = $uploadsDir . $newFilename;

            // Move the uploaded file
            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                // Update the profile_picture attribute in the database
                $sql = "UPDATE user_info SET profile_picture = '$newFilename' WHERE username = '$username'";
                if (mysqli_query($conn, $sql)) {
                    // Return JSON response with the filename
                    echo json_encode(["filename" => $newFilename]);
                } else {
                    echo json_encode(["error" => "Failed to update profile picture in the database."]);
                }
            } else {
                echo json_encode(["error" => "Failed to upload the file."]);
            }
        } else {
            echo json_encode(["error" => "File upload error: " . $file['error']]);
        }
    } else {
        echo json_encode(["error" => "No file uploaded."]);
    }
} else {
    echo json_encode(["error" => "Invalid request method."]);
}
?>