<?php
session_start();
include 'dbconn.php'; // Include your database connection script

header('Content-Type: application/json');

// Check if the user is logged in
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Query to fetch the profile picture filename
    $query = "SELECT img_directory FROM book_info WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $bookPicture = $row['img_directory'];

        // Send the profile picture path as a JSON response
        echo json_encode(['bookimagePath' => 'public/img/userprofilepicture/' . $bookPicture]);
    } else {
        // User not found in the database
        echo json_encode(['error' => 'User not found.']);
    }
} else {
    // User is not logged in
    echo json_encode(['error' => 'User not logged in.']);
}
?>
