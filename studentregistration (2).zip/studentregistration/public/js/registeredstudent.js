var formatBlock = function () {
  return {
    message:
      'Please Wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>',
    css: {
      border: "none",
      padding: "15px",
      backgroundColor: "#000",
      "-webkit-border-radius": "10px",
      "-moz-border-radius": "10px",
      opacity: 0.5,
      color: "#fff",
    },
  };
};

var registeredStudentTable = function () {
  var studentTable = $("#example").DataTable({
    // "ordering": false,
    sAjaxSource: "getRegisteredStudent.php",
    sAjaxDataProp: "value",

    aoColumns: [
      {
        mDataProp: "id",
      },
      {
        mDataProp: "name",
      },
      {
        mDataProp: "gender",
      },
      {
        mDataProp: "mobile_number",
      },
      {
        mDataProp: "age",
      },
      {
        mDataProp: "body_temperature",
      },
      {
        mDataProp: "covid_diagnosed",
      },
      {
        mDataProp: "covid_encounter",
      },
      {
        mDataProp: "covid_vaccinated",
      },
      {
        mDataProp: "nationality",
      },
    ],
  });
};

var RegisteredStudent = (function () {
  "use strict";

  return {
    init: function () {
      registeredStudentTable();
    },
  };
})();
