

var formatBlock = function() {
    return {
        message: 'Please Wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>',
        css: {
            border: 'none',
            padding: '15px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .5,
            color: '#fff',
            width: '200px'
        }
    };
}

// var checkSession = function() {
//     $.get('api/checksession.php', function(data) {
//         var sessiondata = $.parseJSON(data);
//         if(sessiondata.isSuccess) {
//             $(location).attr('href','dashboard.html');
//         }
//     });
// };

// var handleFormEvents = function(){
//     $.validate({
//        form : '#frmSignUp',
//        modules: 'security'
//     });
// };


var onRegisterStudents = function(){
    $("#frmSignUp").submit(function(event) {
        event.preventDefault();
        $('#signup').block(formatBlock());
        var signUpObj = $("#frmSignUp").serializeArray();

        $.post('registerUser.php', signUpObj, function(data){
            
           var msg = data.msg;

            var alert = "<div class='alert alert-success fade in'>" +
                "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>" +
                "<strong>Message!</strong>  <br/>" + msg +
            "</div>";

            if(data.isSuccess) {

                // $(location).attr('href','dashboard.html');
                $("#signup-msg").html(alert);
                $('#name').val('');
                $('#gender').val('');
                $('#mobile_number').val('');
                $('#age').val('');
                $('#body_temperature').val('');
                $('#covid_diagnosed').val('');
                $('#covid_encounter').val('');
                $('#covid_vaccinated').val('');
                $('#nationality').val('');
     
            } else {
                $("#signup-msg").html(alert);
            }

            $('#signup').unblock();
        }, 'json');
   
    });
}
            // if(data.isSuccess) {

    $('#name').val('');
                $('#gender').val('');
                $('#mobile_number').val('');
                $('#age').val('');
                $('#body_temperature').val('');
                $('#covid_diagnosed').val('');
                $('#covid_encounter').val('');
                $('#covid_vaccinated').val('');
                $('#nationality').val('');
     
            
                  // var alert = "<div class='alert alert-success fade in'>" +
                  //   "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>" +
                  //   "<strong>Message!</strong>  <br/> Your Password was Successfully Change.</div>";
                  //    $("#signup-msg").html(alert);
                
            // } 
    //     }, 'json');
   
    // });
// }

var Userrecord = function() {
    "use strict";
    
    return {
        init: function() {
              onRegisterStudents()
                // onSubmitRegister()
            // getPersonalInfo(),
            // getAcademicInfo(),
            // getScholarType(),
            // getSchoolYearList(),
            // //getDutyhoursko(),
            // onChangeSchoolYearDuty()
        }
    }
}()
//  