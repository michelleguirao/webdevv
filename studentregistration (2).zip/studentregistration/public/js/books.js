async function getCurrentUser() {
  try {
    const response = await fetch("php/getcurrentuser.php"); // Replace with your endpoint
    const data = await response.json();

    if (data.error) {
      alert(data.error); // Notify if there's an error (e.g., not logged in)
      return null;
    }

    return data.username; // Return the logged-in user's username
  } catch (error) {
    console.error("Error fetching current user:", error);
    return null;
  }
}

// Fetch and display books
async function fetchBooks() {
  const response = await fetch("php/books.php"); // Use the combined PHP script
  const books = await response.json();

  if (books.error) {
    console.error("Error fetching books:", books.error);
    return;
  }

  const tableBody = document.querySelector("#bookTable tbody");
  tableBody.innerHTML = "";

  books.forEach((book) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${book.id}</td>
      <td>${book.bname}</td>
      <td>${book.author}</td>
      <td>${book.date}</td>
      <td>${book.synopsis}</td>
      <td><img src="${book.img_directory}" alt="${book.bname}" width="100" height="100" /></td>
      <td>${book.status}</td>
    `;
    tableBody.appendChild(row);
  });
}

// Borrow book
async function borrowBook(bookId, buttonElement) {
  // Send a POST request to the server with the book ID
  const response = await fetch("php/borrow.php", {
    method: "POST", // Use POST method for the request
    headers: {
      "Content-Type": "application/json", // Specify that the request body is JSON
    },
    // Convert the book ID into a JSON string and send it in the request body
    body: JSON.stringify({ id: bookId }),
  });

  // Parse the JSON response from the server
  const data = await response.json();

  // Check if the response status indicates success
  if (response.ok) {
    // Find the parent cell of the button and replace its content with "Pending"
    const statusCell = buttonElement.parentElement;
    statusCell.innerHTML = "Pending";
    // Notify the user that the borrow request was successful
    alert("Thank you for borrowing the book. Please wait for confirmation.");
  } else {
    // Display an error message if the request failed
    alert(data.error || "Error borrowing the book.");
  }
}

fetch("php/getbookpic.php")
  .then((response) => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  })
  .then((data) => {
    if (data.bookimagePath) {
      const bookPicture = document.getElementById("bookpicture");
      bookPicture.src = data.bookimagePath; // Dynamically set the image path
    } else {
      console.error("Error in response:", data.error);
    }
  })
  .catch((error) => {
    console.error("Error fetching profile image:", error);
  });

// Initialize the table on page load by calling fetchBooks
fetchBooks();
