-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2024 at 08:24 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_info`
--

CREATE TABLE `book_info` (
  `id` int(100) NOT NULL,
  `bname` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `synopsis` varchar(500) NOT NULL,
  `img_directory` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL,
  `users_username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_info`
--

INSERT INTO `book_info` (`id`, `bname`, `author`, `date`, `synopsis`, `img_directory`, `status`, `users_username`) VALUES
(1, 'asdawd', 'adwada', '0000-00-00', 'sgadgrg', 'serse', 'Pending', 'michwada3'),
(2, 'asdsdads', 'asdasdsa', '0000-00-00', 'sdffsfsd', 'sfds', '0', 'michwada3'),
(3, 'sada', 'awd', '0000-00-00', 'waddd', 'aaaaa', 'Pending', 'michwada3'),
(4, 'awdda', 'awdawd', '2024-11-05', 'awdawdwa', 'asfawdawd', '0', 'asfdadawdwd');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `is_admin`) VALUES
(9, 'user1', '$2y$10$KzRyJyc08m5RM85.RzAosOTz7kqNEf9Wn0eXK25kIis7DWgtNhQFy', 0),
(10, 'admin', '$2y$10$YzcF3Dp.BedIYpHWyVWeKOFIR1Nl.WeKqmYPDgoqcHyDahlKnLeKG', 1),
(12, 'mich', '$2y$10$lLD/2IdNLdpZAa5B8BD5tOKqFd/zdm3fJ0KOs6JS2q.DojFSANsK.', 0),
(13, '2bg', '$2y$10$9NWjMwNRWli/0Rz2XiOYpepbnzjxkHZe1BMPwf1dSJl8ObDJVQjau', 0),
(14, '2321', '$2y$10$rFMQshGwfyhQyeszfhEYYupHVSRt1GfxidkDhHFzdP53AIWRhmuKW', 0),
(16, 'jess', '$2y$10$UI.QJL7sawlLgM8SHbBKve84ZBWv4nIeq.g1XBsOpYGpOGLF7.MaO', 0),
(19, 'michelle', '$2y$10$MNvphFNfi1N3Jm6Q7FdbK.PH5JCO2GLE6mNWJdo9OK4owCtTjqiw6', 0),
(39, 'michwada', '$2y$10$AGk6SENCJkMc2bCr4Z5Cd.WfFqjIsw7XScCuT8GYeqsp1OLGUCIru', 0),
(40, 'Dioneyys', '$2y$10$K7kfVBJ6H9KAF529RO7QlOyXQmxRg3nVwffDsyswPPAgnWYLEYtvG', 0),
(41, 'Mamamo', '$2y$10$NjHFs.40UGl9qn8RdaC8yep7nRVwOQapcsfHvxJiyswvA1qHx1p42', 0),
(42, 'Korean', '$2y$10$25nehCdCeJ2RVTk4AQulheaSylUGfsMhBrUGqS4LvBgR/r1OsVOGC', 0),
(43, 'mizyco', '$2y$10$0t3K6ztfz3EZ57dKyTynaOe3dDYBJe8vwofOxvKWLHkIBx0t8trz2', 0),
(44, 'michong', '$2y$10$2PFMiwKDNZSjBoXNoK9U1.HeO6Q8EbHyMAjgi1bgFI92fWg2fQbvW', 0),
(45, 'michwada2', '$2y$10$X9oUSmSChUx5E5JA56kgiOw4iOBP3uKPi9xNx9JZPF5AQVTRlhhGW', 0),
(46, 'senby', '$2y$10$ZLbK.GWFv1PTtV84UYjq4.csoOVbP8RyBi1fyaACW6dUkUt3qAiJa', 0),
(47, 'michwada3', '$2y$10$kCYRVcIjMr8yG0FkOoqw5eavSuXfg1s8Lxf9tEpisM0EuhtqNyH2e', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `mobile_number` varchar(20) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `year_section` int(3) DEFAULT NULL,
  `course` enum('BSIS','BSN','PSYCH','BSCE','MIDWIFERY') NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `username` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `fname`, `lname`, `mobile_number`, `age`, `year_section`, `course`, `gender`, `username`) VALUES
(1, 'Senby', 'Bicomong', '219491412', 19, 201, 'BSN', 'Female', 'senby'),
(8, 'abdul', 'chong', '21949141', 6, 213, 'BSIS', 'Male', 'admin'),
(9, 'michwada', 'mich3', '1232131', 123131, 12321, 'BSIS', 'Male', 'michwada3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_info`
--
ALTER TABLE `book_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_username` (`username`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_username_user_info` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_info`
--
ALTER TABLE `book_info`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_info`
--
ALTER TABLE `user_info`
  ADD CONSTRAINT `fk_username_user_info` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
