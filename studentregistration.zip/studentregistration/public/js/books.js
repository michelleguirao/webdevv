async function getCurrentUser() {
  try {
    const response = await fetch("php/getcurrentuser.php"); // Replace with your endpoint
    const data = await response.json();

    if (data.error) {
      alert(data.error); // Notify if there's an error (e.g., not logged in)
      return null;
    }

    return data.username; // Return the logged-in user's username
  } catch (error) {
    console.error("Error fetching current user:", error);
    return null;
  }
}

// Fetch and display books
async function fetchBooks() {
  const currentUser = await getCurrentUser();

  if (!currentUser) {
    alert("Please log in to view books.");
    return; // Stop execution if no user is logged in
  }
  const response = await fetch("php/books.php");
  // kuhain response from books
  const books = await response.json();
  const tableBody = document.querySelector("#bookTable tbody");
  // Clear any existing rows in table tbody
  tableBody.innerHTML = "";

  // Iterate through each book
  books.forEach((book) => {
    // Create a new table row (<tr>) per book
    const row = document.createElement("tr");
    // Set a custom data attribute to store the book's ID
    row.setAttribute("data-book-id", book.id);

    // Populate the row with book details using template literals
    row.innerHTML = `
      <td>${book.id}</td> <!-- Display book ID -->
      <td>${book.bname}</td> <!-- Display book name -->
      <td>${book.author}</td> <!-- Display book author -->
      <td>${book.date}</td> <!-- Display publication date -->
      <td>${book.synopsis}</td> <!-- Display book synopsis -->
      <td><img src="${book.img_directory}" alt="${
      book.bname
    }" /></td> <!-- Display book image -->
      <td class="status-cell">
       ${
         book.status === "Pending"
           ? book.users_username === currentUser
             ? "Pending" // The logged-in user has borrowed this book
             : "Unavailable" // Another user has borrowed this book
           : `<button onclick="borrowBook(${book.id}, this)">Borrow</button>` // Book is available
       }
      </td>
    `;
    // Append the populated row to the table body
    tableBody.appendChild(row);
  });
}

// Borrow book
async function borrowBook(bookId, buttonElement) {
  // Send a POST request to the server with the book ID
  const response = await fetch("php/borrow.php", {
    method: "POST", // Use POST method for the request
    headers: {
      "Content-Type": "application/json", // Specify that the request body is JSON
    },
    // Convert the book ID into a JSON string and send it in the request body
    body: JSON.stringify({ id: bookId }),
  });

  // Parse the JSON response from the server
  const data = await response.json();

  // Check if the response status indicates success
  if (response.ok) {
    // Find the parent cell of the button and replace its content with "Pending"
    const statusCell = buttonElement.parentElement;
    statusCell.innerHTML = "Pending";
    // Notify the user that the borrow request was successful
    alert("Thank you for borrowing the book. Please wait for confirmation.");
  } else {
    // Display an error message if the request failed
    alert(data.error || "Error borrowing the book.");
  }
}
fetch("php/getbookpic.php")
  .then((response) => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  })
  .then((data) => {
    if (data.bookimagePath) {
      const bookPicture = document.getElementById("bookpicture");
      bookPicture.src = data.bookimagePath; // Dynamically set the image path
    } else {
      console.error("Error in response:", data.error);
    }
  })
  .catch((error) => {
    console.error("Error fetching profile image:", error);
  });

// Initialize the table on page load by calling fetchBooks
fetchBooks();
