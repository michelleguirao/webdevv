var formatBlock = function (blockmsg) {
  return {
    message: blockmsg,
    css: {
      border: "none",
      padding: "15px",
      backgroundColor: "#000",
      "-webkit-border-radius": "10px",
      "-moz-border-radius": "10px",
      opacity: 0.5,
      color: "#fff",
      width: "200px",
    },
  };
};

var checkSession = function () {
  $.get("checksession.php", function (data) {
    var sessiondata = $.parseJSON(data);
    if (!sessiondata.isSuccess) {
      $(location).attr("href", "login.html");
    } else {
      loadFirst();
    }
  });
};

var loadFirst = function () {
  setTimeout(function () {
    $("#core").removeClass("hidden");
    // $('#loader').addClass('hidden');
  }, 1000);
};

if (typeof $.blockUI === "function" && typeof $.unblockUI === "function") {
  console.log("BlockUI functions are available!");
} else {
  console.log(
    "BlockUI functions are not available. Please ensure the plugin is loaded correctly."
  );
}

// User Information Click Handler
$("#user_info").click(function () {
  var blockmsg =
    'Please wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>';
  /**
   * User Information block ui
   */
  $("#main-content").block(formatBlock(blockmsg));
  $("#main-content").fadeOut(400, function () {
    $.get("userinformation.html", function (data) {
      $("#main-content").html(data);
      $("#main-content").fadeIn(400, function () {
        // Call the function to fetch and display the profile picture
        // fetchProfilePicture();
        // $("#main-content").unblock();
      });
    });
  });
});

// Fetch the dynamic image path from the server
fetch("php/getpfp.php")
  .then((response) => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json(); // Parse JSON from response
  })
  .then((data) => {
    const profilePicture = document.getElementById("profilepicture");
    if (data.profile_picture) {
      profilePicture.src = data.profile_picture; // Dynamically set the image path
    } else {
      console.error("No image path returned from the server.");
    }
  })
  .catch((error) => {
    console.error("Error fetching profile image:", error);
  });

fetch("php/getpfp.php")
  .then((response) => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  })
  .then((data) => {
    if (data.imagePath) {
      const profilePicture = document.getElementById("profilepicture");
      profilePicture.src = data.imagePath; // Dynamically set the image path
    } else {
      console.error("Error in response:", data.error);
    }
  })
  .catch((error) => {
    console.error("Error fetching profile image:", error);
  });

// Books Click Handler
$("#books").click(function () {
  var blockmsg =
    'Please wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>';
  /**
   * books Block UI
   */
  $("#main-content").block(formatBlock(blockmsg));
  $("#main-content").fadeOut(400, function () {
    $.get("books.html", function (data) {
      $("#main-content").html(data);
      $("#main-content").fadeIn(400, function () {
        $("#main-content").unblock();
      });
    });
  });
});

// Bag Click Handler
$("#bag").click(function () {
  var blockmsg =
    'Please wait <img style="display:inline;width:20px;height:20px;" src="public/img/loader.gif"/>';
  /**
   * Bag block ui
   */
  $("#main-content").block(formatBlock(blockmsg));
  $("#main-content").fadeOut(400, function () {
    $.get("bag.html", function (data) {
      $("#main-content").html(data);
      $("#main-content").fadeIn(400, function () {
        $("#main-content").unblock();
      });
    });
  });
});

var Index = (function () {
  "use strict";

  return {
    init: function () {
      checkSession();
    },
  };
})();
