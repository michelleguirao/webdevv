<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('dbconn.php'); // Include the database connection

// Initialize the database connection
$config = new Config();
$conn = $config->conn;

// Handle fetch request to get all records
// if (isset($_POST['fetch'])) {
//     fetchBookRecords($conn);
//     exit;
// }

// Handle record update
if (isset($_POST['update'])) {
    updateBookRecord($conn, $_POST['id'], $_POST['update_data']);
    exit;
}

// Handle record delete
if (isset($_POST['delete'])) {
    deleteBookRecord($conn, $_POST['id']);
    exit;
}

// Handle adding a new book
if (isset($_POST['add'])) {
    addBookRecord($conn, $_POST, $_FILES['img_directory'] ?? null);
    exit;
}

// Close connection
$conn->close();

function fetchBookRecords($conn) {
    $sql = "SELECT * FROM book_info";
    $result = $conn->query($sql);

    if ($result) {
        $rows = [];
        while ($row = $result->fetch_assoc()) {
            // Ensure the image path is returned correctly
            $row['img_directory'] = $row['img_directory'];  // You may need to adjust the path if necessary
            $rows[] = $row;
        }
        echo json_encode($rows); // Return books as JSON
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to fetch records: ' . $conn->error]);
    }
}

/**
 * Update a book record
 */
function updateBookRecord($conn, $id, $updateData) {
    foreach ($updateData as $data) {
        $column = $conn->real_escape_string($data['column']);
        $newValue = $conn->real_escape_string($data['new_value']);

        $sql = "UPDATE book_info SET $column = '$newValue' WHERE id = $id";

        if (!$conn->query($sql)) {
            echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
            return;
        }
    }
    echo json_encode(['status' => 'success', 'message' => 'Record updated successfully']);
}

/**
 * Delete a book record
 */
function deleteBookRecord($conn, $id) {
    $sql = "DELETE FROM book_info WHERE id = $id";

    if ($conn->query($sql)) {
        echo json_encode(['status' => 'success', 'message' => 'Record deleted successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
    }
}

/**
 * Add a new book record
 */
function addBookRecord($conn, $postData, $file) {
    // Sanitize input data
    $bname = $conn->real_escape_string($postData['bname']);
    $author = $conn->real_escape_string($postData['author']);
    $synopsis = $conn->real_escape_string($postData['synopsis']);
    $date = $postData['date'];
    $status = $conn->real_escape_string($postData['status']);

    // Handle file upload
    $imgDirectory = null;
    if ($file && $file['error'] === 0) {
        $targetDir = 'public/img/';
        $targetFile = $targetDir . basename($file['name']);

        // Validate file type
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
        if (in_array($file['type'], $allowedTypes)) {
            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                $imgDirectory = $targetFile;
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to upload image']);
                return;
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid file type']);
            return;
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No image file provided or an error occurred']);
        return;
    }

    // Insert data into the database
    $sql = "INSERT INTO book_info (bname, author, date, synopsis, img_directory, status)
            VALUES ('$bname', '$author', '$date', '$synopsis', '$imgDirectory', '$status')";

    if ($conn->query($sql)) {
        echo json_encode(['status' => 'success', 'message' => 'New record added successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
    }
}
?>
