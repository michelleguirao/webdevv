<?php
include 'dbconn.php';  // Ensure your dbconn.php is correctly set up

// Get the status filter from the URL parameter (default is 'all')
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'all';
$currentUser = isset($_GET['user']) ? $_GET['user'] : '';

// Prepare the SQL query based on the status filter
if ($statusFilter == 'all') {
    // Get books that are either Pending or Borrowed for the current user
    $sql = "SELECT id, bname, status FROM book_info WHERE status IN ('Pending', 'Borrowed') AND users_username = ?";
} else {
    // If the filter contains 'Pending,Borrowed', split it and fetch both statuses
    $statusArray = explode(',', $statusFilter);  // Split 'Pending,Borrowed' into an array
    $sql = "SELECT id, bname, status FROM book_info WHERE status IN (?, ?) AND users_username = ?";
}

// Prepare and execute the SQL statement
$stmt = $conn->prepare($sql);

// If the status is not "all", bind the status parameters
if ($statusFilter != 'all') {
    $stmt->bind_param("sss", $statusArray[0], $statusArray[1], $currentUser);
} else {
    $stmt->bind_param("s", $currentUser);
}

$stmt->execute();
$result = $stmt->get_result();

$books = [];
while ($row = $result->fetch_assoc()) {
    $books[] = $row;
}

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($books);

$stmt->close();
$conn->close();
?>
