<?php
session_start();
require_once('dbconn.php');

function saveLogin($username, $password) {
    $response = array();

    // Initialize the database connection
    $config = new Config();
    $conn = $config->conn;

    // Check for connection errors
    if ($conn->connect_error) {
        return "Connection failed: " . $conn->connect_error;
    } else {
        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Prepare the SQL query to insert data
        $query = 'INSERT INTO users (username, password) VALUES (?, ?)';
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('ss', $username, $hashedPassword);

            // Execute the query
            if ($stmt->execute()) {
                // Store the username in the session for later use
                $_SESSION['username'] = $username;

                $response['status'] = 'success';
                $response['message'] = 'User registered successfully!';

                header("Location: http://localhost/studentregistration/fillUp.html");
                exit;
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Failed to register user.';
            }

            // Close the statement
            $stmt->close();
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Failed to prepare statement.';
        }
    }

    // Close the database connection
    $conn->close();

    // Return the response
    return $response;
}

// Example usage
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Create an instance and save user data
    $result = saveLogin($username, $password);

    // Output the result as JSON
    echo json_encode($result);
}
?>
