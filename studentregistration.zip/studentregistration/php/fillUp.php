<?php
session_start();
require_once('dbconn.php');

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: signUp.html"); // Redirect to signup page if not logged in
    exit;
}

function saveUserInfo($fname, $lname, $mobile_number, $age, $year_section, $course, $gender) {
    $response = array();

    // Retrieve the logged-in user's username from the session
    $username = $_SESSION['username'];

    // Initialize database connection
    $config = new Config();
    $conn = $config->conn;

    if ($conn->connect_error) {
        return "Connection failed: " . $conn->connect_error;
    } else {
        // Prepare the SQL query to insert data into user_info
        $query = 'INSERT INTO user_info (fname, lname, mobile_number, age, year_section, course, gender, username) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('sssissss', $fname, $lname, $mobile_number, $age, $year_section, $course, $gender, $username);

            // Execute the query
            if ($stmt->execute()) {
                echo "<script>
                        alert('User information saved successfully!');
                        window.location.href = 'http://localhost/studentregistration/login.html';  // Redirect to login page
                      </script>";
                exit;
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Failed to save user information.';
            }

            // Close the statement
            $stmt->close();
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Failed to prepare the statement.';
        }
    }

    // Close the database connection
    $conn->close();

    // Return the response
    return $response;
}

// Process the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobile_number = $_POST['mobile_number'];
    $age = $_POST['age'];
    $year_section = $_POST['year_section'];
    $course = $_POST['course'];
    $gender = $_POST['gender'];

    // Save user info
    $result = saveUserInfo($fname, $lname, $mobile_number, $age, $year_section, $course, $gender);

    // Output the result (for debugging or API use)
    echo json_encode($result);
}
?>
