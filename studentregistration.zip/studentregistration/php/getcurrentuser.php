<?php
session_start();
include("dbconn.php");

// Check if the user is logged in
if (isset($_SESSION['username'])) {
    echo json_encode(["username" => $_SESSION['username']]);
} else {
    // Return an error if the user is not logged in
    echo json_encode(["error" => "User not logged in"]);
}
?>
